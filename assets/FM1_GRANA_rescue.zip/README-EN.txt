FM-1 ROM recovery with the GRANA kit

For WL80UBOOT1.00 (USB 4C4A:8057) only. Extract the complete folder on a Raspberry Pi or Linux PC. Connect the FM-1 directly by USB. In the extracted folder run sudo python3 recupera_fm1.py. The tool checks its files and the chip, reads the full flash twice and saves it in copie/ before asking for SI to write. Keep the backup and log. It restores GRANA first. Power off and restart as directed, then use the Mariotronics editor to install Mariotronics. The original tool and prompts are in Italian. See LEGGIMI.txt.
